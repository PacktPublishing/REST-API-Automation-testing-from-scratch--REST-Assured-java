package TestFramework;

public class resources {

	
	public static String placePostData()
	{
		
		String res="/maps/api/place/add/json";
		return res;
	}
	
	
	


}
